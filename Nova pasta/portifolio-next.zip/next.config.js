// Next.js config será gerado
