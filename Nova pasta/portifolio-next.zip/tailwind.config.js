// Tailwind config será gerado
